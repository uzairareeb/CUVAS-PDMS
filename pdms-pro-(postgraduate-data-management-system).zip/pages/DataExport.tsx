import React from 'react';
import { useStore } from '../store';
import { 
  Download, 
  FileSpreadsheet, 
  ShieldCheck, 
  Database, 
  FileText,
  LayoutGrid,
  ChevronRight,
  GraduationCap
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

const DataExport: React.FC = () => {
  const { students, backupDatabase, settings } = useStore();

  const MASTER_HEADERS = [
    'cnic', 'name', 'fatherName', 'regNo', 'gender', 'contactNumber', 
    'degree', 'session', 'department', 'programme', 'currentSemester', 'status',
    'supervisorName', 'coSupervisor', 'member1', 'member2', 'thesisId', 
    'synopsis', 'synopsisSubmissionDate', 'gs2CourseWork', 'gs4Form',
    'semiFinalThesisStatus', 'semiFinalThesisSubmissionDate', 
    'finalThesisStatus', 'finalThesisSubmissionDate', 
    'thesisSentToCOE', 'coeSubmissionDate', 
    'validationStatus', 'validationDate', 'comments'
  ];

  const downloadCSV = () => {
    if (students.length === 0) return;
    
    const csvContent = [
      MASTER_HEADERS.join(','),
      ...students.map(s => MASTER_HEADERS.map(header => `"${(s as any)[header] || ''}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CUVAS_Master_Registry_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const downloadPDF = () => {
    if (students.length === 0) return;
    
    const doc = new jsPDF('l', 'mm', 'a4');
    const pageWidth = doc.internal.pageSize.getWidth();
    
    // Header
    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(settings.institution.name.toUpperCase(), pageWidth / 2, 15, { align: 'center' });
    
    doc.setFontSize(10);
    doc.text(settings.institution.directorate.toUpperCase(), pageWidth / 2, 22, { align: 'center' });
    
    doc.setFontSize(8);
    doc.setTextColor(100);
    doc.text(`Master Scholar Registry - Extracted: ${new Date().toLocaleString()}`, pageWidth / 2, 28, { align: 'center' });

    // Table
    const tableHeaders = [['Reg #', 'Scholar Name', 'Degree', 'Specialization', 'Supervisor', 'Status', 'Audit']];
    const tableData = students.map(s => [
      s.regNo,
      s.name,
      s.degree,
      s.programme,
      s.supervisorName,
      s.status,
      s.validationStatus
    ]);

    autoTable(doc, {
      startY: 35,
      head: tableHeaders,
      body: tableData,
      theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2 },
      headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    doc.save(`CUVAS_Master_Registry_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in duration-700 pb-20 px-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-2">
        <div className="space-y-2">
          <div className="flex items-center space-x-3">
             <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-lg shadow-indigo-600/20">
                <LayoutGrid size={24} />
             </div>
             <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Export Intelligence</h1>
          </div>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.3em] ml-1">Official Registry Extraction Protocols</p>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="hidden sm:flex flex-col items-end">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Available Records</span>
              <span className="text-xl font-black text-indigo-600 tabular-nums">{students.length} Nodes</span>
           </div>
        </div>
      </div>

      {/* Export Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        
        <ExportCard 
          icon={FileSpreadsheet} 
          title="Global CSV" 
          desc="Full extraction of all 30 scholar data points for deep spreadsheet analysis."
          color="indigo"
          onClick={downloadCSV}
          actionLabel="Extract All Data"
        />

        <ExportCard 
          icon={FileText} 
          title="Master Registry PDF" 
          desc="Professional formatted landscape report optimized for official printing."
          color="rose"
          onClick={downloadPDF}
          actionLabel="Generate Report"
        />

        <ExportCard 
          icon={Database} 
          title="Institutional Backup" 
          desc="Complete system state dump for data redundancy and disaster recovery."
          color="emerald"
          onClick={backupDatabase}
          actionLabel="Execute Backup"
        />

      </div>

      {/* Security Advisory */}
      <div className="bg-[#0f172a] p-12 rounded-[4rem] text-white shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-12 opacity-5">
          <ShieldCheck size={160} />
        </div>
        <div className="flex flex-col md:flex-row items-center gap-10 relative z-10">
          <div className="p-6 bg-white/5 rounded-[2rem] border border-white/10 shrink-0">
             <ShieldCheck size={48} className="text-indigo-400" />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-black tracking-tight uppercase">Registry Security Protocol</h3>
            <p className="text-slate-500 text-sm font-medium leading-relaxed max-w-2xl">
              All data extractions are logged with timestamp and user identity. Ensure all exported files are handled in compliance with institutional data protection policies.
            </p>
          </div>
          <div className="flex-1 flex justify-end">
             <div className="px-6 py-3 bg-indigo-600/20 text-indigo-400 text-[10px] font-black uppercase tracking-widest border border-indigo-400/30 rounded-full">
               System Logging Active
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ExportCard = ({ icon: Icon, title, desc, color, onClick, actionLabel }: any) => (
  <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-xl shadow-slate-200/30 flex flex-col justify-between group hover:-translate-y-2 transition-all duration-500">
    <div className="space-y-8">
      <div className={`p-5 bg-${color}-50 text-${color}-600 rounded-[2rem] w-fit shadow-inner group-hover:bg-${color}-600 group-hover:text-white transition-all duration-500`}>
        <Icon size={32} />
      </div>
      <div>
        <h3 className="text-xl font-black text-slate-900 tracking-tight uppercase leading-none">{title}</h3>
        <p className="text-slate-500 text-xs font-medium mt-4 leading-relaxed">{desc}</p>
      </div>
    </div>
    
    <button 
      onClick={onClick}
      className={`w-full mt-10 py-5 bg-[#0f172a] text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-${color}-600 transition-all shadow-lg flex items-center justify-center space-x-3 group/btn`}
    >
      <span>{actionLabel}</span>
      <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
    </button>
  </div>
);

export default DataExport;