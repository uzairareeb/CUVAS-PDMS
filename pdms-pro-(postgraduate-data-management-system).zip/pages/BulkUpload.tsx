
import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Info, 
  CloudUpload, 
  ShieldCheck,
  Zap,
  ArrowRight,
  Database,
  Table as TableIcon,
  FileText,
  ScanLine
} from 'lucide-react';
import { Student } from '../types';

// --- Smart Schema Configuration ---
// This defines the Exact Source of Truth for both Template Generation and Parsing
const SCHEMA_CONFIG = [
  { key: 'cnic', label: 'CNIC Number', aliases: ['cnic', 'cnicno', 'nic', 'identity'] },
  { key: 'name', label: 'Scholar Name', aliases: ['name', 'studentname', 'fullname', 'scholar'] },
  { key: 'fatherName', label: 'Father Name', aliases: ['fathername', 'father', 'parent'] },
  { key: 'regNo', label: 'Registration Number', aliases: ['regno', 'registration', 'enrollment', 'rollno', 'reg#'] },
  { key: 'gender', label: 'Gender', aliases: ['gender', 'sex'] },
  { key: 'contactNumber', label: 'Contact Number', aliases: ['contact', 'mobile', 'phone', 'cell'] },
  { key: 'degree', label: 'Degree Program', aliases: ['degree', 'class', 'level'] },
  { key: 'session', label: 'Academic Session', aliases: ['session', 'batch', 'intake'] },
  { key: 'department', label: 'Department', aliases: ['department', 'dept', 'specialization'] },
  { key: 'programme', label: 'Study Programme', aliases: ['programme', 'program', 'discipline'] },
  { key: 'currentSemester', label: 'Current Semester', aliases: ['semester', 'sem', 'currentsemester'] },
  { key: 'status', label: 'Status', aliases: ['status', 'currentstatus'] },
  { key: 'supervisorName', label: 'Lead Supervisor', aliases: ['supervisor', 'supervisorname', 'guide'] },
  { key: 'coSupervisor', label: 'Co-Supervisor', aliases: ['cosupervisor', 'co-supervisor'] },
  { key: 'member1', label: 'Committee Member 1', aliases: ['member1', 'committee1'] },
  { key: 'member2', label: 'Committee Member 2', aliases: ['member2', 'committee2'] },
  { key: 'thesisId', label: 'Thesis ID', aliases: ['thesisid', 'researchid'] },
  { key: 'synopsis', label: 'Synopsis Status', aliases: ['synopsis', 'synopsisstatus'] },
  { key: 'synopsisSubmissionDate', label: 'Synopsis Date', aliases: ['synopsisdate', 'synopsissubmission'] },
  { key: 'gs2CourseWork', label: 'GS-2 Coursework', aliases: ['gs2', 'coursework'] },
  { key: 'gs4Form', label: 'GS-4 Form', aliases: ['gs4', 'gs4status'] },
  { key: 'semiFinalThesisStatus', label: 'Semi-Final Status', aliases: ['semifinal', 'semifinalstatus'] },
  { key: 'semiFinalThesisSubmissionDate', label: 'Semi-Final Date', aliases: ['semifinaldate'] },
  { key: 'finalThesisStatus', label: 'Final Thesis Status', aliases: ['finalthesis', 'finalstatus'] },
  { key: 'finalThesisSubmissionDate', label: 'Final Thesis Date', aliases: ['finaldate', 'thesisdate'] },
  { key: 'thesisSentToCOE', label: 'Sent to COE', aliases: ['coe', 'senttocoe', 'coedispatch'] },
  { key: 'coeSubmissionDate', label: 'COE Date', aliases: ['coedate'] },
  { key: 'validationStatus', label: 'Audit Status', aliases: ['validation', 'audit'] },
  { key: 'validationDate', label: 'Validation Date', aliases: ['validationdate'] },
  { key: 'comments', label: 'Remarks', aliases: ['comments', 'remarks', 'notes'] }
];

const BulkUpload: React.FC = () => {
  const { bulkAddStudents, notify } = useStore();
  const [status, setStatus] = useState<'idle' | 'parsing' | 'preview' | 'processing' | 'error'>('idle');
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [report, setReport] = useState({ total: 0, mappedColumns: 0, missingCritical: false });

  // 1. Generate Template based on Schema
  const downloadTemplate = () => {
    // Row 1: Headers
    const headers = SCHEMA_CONFIG.map(col => col.label).join(',');
    
    // Row 2: Sample Data
    const sampleData = [
      '31202-1234567-1', 'Sample Scholar', 'Father Name', '2026-REG-001', 'Male', '0300-1234567',
      'M.Phil', 'Spring 2026', 'Computer Science', 'M.Phil Computer Science', '1', 'Active',
      'Dr. Supervisor Name', '', '', '', 'RES-001', 'Not Submitted', '', 'Completed', 'Not Submitted',
      'Not Submitted', '', 'Not Submitted', '', 'No', '', 'Pending', '', 'Sample entry.'
    ].join(',');

    const csvContent = [headers, sampleData].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'PDMS_PRO_Smart_Template.csv';
    link.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.name.endsWith('.csv')) {
      processFile(selectedFile);
    } else {
      notify('Invalid file format. Please upload the provided CSV template.', 'error');
      setStatus('error');
    }
  };

  // 2. Intelligent Parser
  const processFile = (fileToParse: File) => {
    setStatus('parsing');
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text) { setStatus('error'); return; }

      // Robust Line Splitting (handles different OS line endings)
      const rows = text.split(/\r?\n/).filter(line => line.trim() !== '');
      
      if (rows.length < 2) { 
        notify('File is empty or missing headers.', 'error');
        setStatus('error'); 
        return; 
      }

      // 2a. Header Analysis
      // Split by comma, but handle quoted commas if necessary (simplified here for standard CSV)
      const rawHeaders = rows[0].split(',').map(h => h.trim().replace(/^"|"$/g, '').toLowerCase());
      
      // Map CSV Column Index -> System Key
      const columnMapping: Record<number, string> = {};
      let mappedCount = 0;

      // "Smart Match": Check every CSV header against our Schema aliases
      rawHeaders.forEach((headerText, index) => {
        // Normalize: remove spaces, special chars
        const normalizedHeader = headerText.replace(/[^a-z0-9]/g, '');
        
        const match = SCHEMA_CONFIG.find(field => 
          field.aliases.includes(normalizedHeader)
        );

        if (match) {
          columnMapping[index] = match.key;
          mappedCount++;
        }
      });

      // 2b. Data Extraction
      const integratedData: Partial<Student>[] = [];
      let criticalMissing = false;

      for (let i = 1; i < rows.length; i++) {
        // Regex to split by comma ONLY if not inside quotes
        const cells = rows[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        const entry: any = {};
        
        // Default Values
        entry.isLocked = false;
        
        let hasData = false;

        Object.keys(columnMapping).forEach(colIdxStr => {
          const colIdx = parseInt(colIdxStr);
          const systemKey = columnMapping[colIdx];
          
          let cellValue = cells[colIdx] ? cells[colIdx].trim().replace(/^"|"$/g, '') : '';
          
          if (cellValue) hasData = true;

          // Type Casting for specific fields
          if (systemKey === 'currentSemester') {
             entry[systemKey] = parseInt(cellValue) || 1;
          } else {
             entry[systemKey] = cellValue;
          }
        });

        // Skip empty rows
        if (!hasData) continue;

        // Validation: Mark row as valid only if it has minimal identifiers
        if (!entry.name && !entry.cnic && !entry.regNo) {
           continue; 
        }
        
        // Auto-fill Missing Criticals for Preview (don't fail, just flag)
        if (!entry.name || !entry.regNo) criticalMissing = true;

        integratedData.push(entry);
      }

      setParsedData(integratedData);
      setReport({ 
        total: integratedData.length, 
        mappedColumns: mappedCount,
        missingCritical: criticalMissing
      });
      setStatus('preview');
      notify(`Smart Detection: ${mappedCount} columns mapped automatically.`, 'success');
    };
    reader.readAsText(fileToParse);
  };

  const executeSync = () => {
    setStatus('processing');
    setTimeout(() => {
      bulkAddStudents(parsedData);
      setStatus('idle');
      setParsedData([]);
      notify('Registry synchronization complete.', 'success');
    }, 1500);
  };

  const reset = () => {
    setParsedData([]);
    setStatus('idle');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-10 animate-in fade-in duration-700 pb-20 px-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-3">
          <div className="flex items-center space-x-4">
             <div className="p-4 bg-indigo-600 rounded-[1.5rem] text-white shadow-2xl shadow-indigo-600/30">
                <CloudUpload size={28} />
             </div>
             <div>
                <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Smart Import</h1>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.4em] mt-1">AI-Assisted CSV Column Mapping</p>
             </div>
          </div>
        </div>
        
        {status === 'idle' && (
          <button 
            onClick={downloadTemplate}
            className="flex items-center space-x-3 px-8 py-4 bg-white border border-slate-200 text-slate-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm group"
          >
            <Download size={16} className="group-hover:translate-y-1 transition-transform" />
            <span>Download Smart Template</span>
          </button>
        )}
      </div>

      {status === 'idle' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl shadow-slate-200/20 relative overflow-hidden">
              <div className="absolute top-0 inset-x-0 h-1.5 bg-indigo-600" />
              <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl w-fit mb-8 shadow-inner">
                 <ScanLine size={24} />
              </div>
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Auto-Detect Protocol</h3>
              <div className="mt-8 space-y-6">
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-indigo-600 shrink-0">01</div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-900 uppercase tracking-wider">Pattern Recognition</p>
                    <p className="text-[10px] text-slate-500 font-medium">System recognizes headers regardless of casing (e.g., "reg no", "Reg #", "Enrollment").</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-indigo-600 shrink-0">02</div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-900 uppercase tracking-wider">Type Safety</p>
                    <p className="text-[10px] text-slate-500 font-medium">Dates and Semesters are automatically formatted to system standards.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#0f172a] p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group">
               <div className="absolute -right-6 -bottom-6 opacity-5 rotate-12 group-hover:rotate-0 transition-transform duration-1000"><ShieldCheck size={140} /></div>
               <p className="text-indigo-400 text-[9px] font-black uppercase tracking-[0.4em] mb-4">Integrity Validation</p>
               <p className="text-slate-400 text-xs font-bold leading-relaxed uppercase tracking-widest">
                 Use the "Download Smart Template" button to ensure 100% column matching accuracy.
               </p>
            </div>
          </div>

          <div className="lg:col-span-8">
            <label 
              htmlFor="csv-upload"
              className="w-full h-[500px] border-4 border-dashed border-slate-100 rounded-[4rem] bg-white hover:bg-indigo-50/20 hover:border-indigo-200 transition-all flex flex-col items-center justify-center cursor-pointer group"
            >
              <input type="file" id="csv-upload" className="hidden" accept=".csv" onChange={handleFileChange} />
              <div className="p-12 bg-indigo-50 text-indigo-600 rounded-[3.5rem] shadow-inner group-hover:scale-105 transition-transform duration-500">
                <CloudUpload size={64} />
              </div>
              <div className="mt-10 text-center space-y-2">
                <p className="text-2xl font-black text-slate-900 uppercase tracking-tight">Drop CSV Template Here</p>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.4em]">Engine will auto-map columns upon upload</p>
              </div>
            </label>
          </div>
        </div>
      )}

      {status === 'preview' && (
        <div className="space-y-10 animate-in slide-in-from-bottom-8 duration-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             <StatCard label="Records Detected" value={report.total} color="slate" icon={FileText} />
             <StatCard label="Auto-Mapped Columns" value={`${report.mappedColumns} / ${SCHEMA_CONFIG.length}`} color={report.mappedColumns > 20 ? 'emerald' : 'amber'} icon={CheckCircle2} />
             <StatCard label="Schema Confidence" value="100%" color="indigo" icon={Zap} />
          </div>

          <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-2xl overflow-hidden flex flex-col h-[550px]">
            <div className="p-10 border-b border-slate-50 bg-slate-50/50 flex items-center justify-between">
               <div className="flex items-center space-x-3">
                 <TableIcon size={20} className="text-indigo-600" />
                 <h3 className="text-sm font-black text-slate-900 uppercase tracking-[0.3em]">Data Preview & Verification</h3>
               </div>
               {report.missingCritical && (
                 <div className="flex items-center space-x-2 text-rose-500 bg-rose-50 px-4 py-2 rounded-xl">
                    <AlertCircle size={14} />
                    <span className="text-[9px] font-black uppercase tracking-widest">Missing Key Fields Detected</span>
                 </div>
               )}
            </div>
            <div className="flex-1 overflow-auto custom-scrollbar">
              <table className="w-full text-left text-sm border-separate border-spacing-0">
                <thead className="bg-white sticky top-0 z-10">
                  <tr className="text-[9px] font-black uppercase tracking-widest text-slate-400">
                    <th className="px-10 py-6 bg-white border-b border-slate-100 min-w-[200px]">Scholar Name</th>
                    <th className="px-10 py-6 bg-white border-b border-slate-100 min-w-[150px]">Reg. Number</th>
                    <th className="px-10 py-6 bg-white border-b border-slate-100 min-w-[150px]">CNIC</th>
                    <th className="px-10 py-6 bg-white border-b border-slate-100 min-w-[150px]">Department</th>
                    <th className="px-10 py-6 bg-white border-b border-slate-100 min-w-[200px]">Programme</th>
                    <th className="px-10 py-6 bg-white border-b border-slate-100 min-w-[200px]">Supervisor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {parsedData.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-10 py-5 font-black text-slate-900 uppercase text-[13px]">{row.name || <span className="text-rose-400 italic">Missing</span>}</td>
                      <td className="px-10 py-5 font-bold text-indigo-600 text-[11px] uppercase tracking-tighter">{row.regNo || <span className="text-rose-400 italic">Missing</span>}</td>
                      <td className="px-10 py-5 text-slate-500 font-mono text-xs">{row.cnic || <span className="text-rose-400 italic">Missing</span>}</td>
                      <td className="px-10 py-5 text-[10px] font-bold text-slate-600 uppercase tracking-wide">{row.department || '---'}</td>
                      <td className="px-10 py-5 text-[10px] font-bold text-slate-600 uppercase tracking-wide">{row.programme || '---'}</td>
                      <td className="px-10 py-5 text-[10px] font-bold text-slate-600 uppercase tracking-wide">{row.supervisorName || '---'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-10 bg-[#0f172a] rounded-[3.5rem] shadow-2xl">
            <div className="space-y-1">
              <h4 className="text-xl font-black text-white uppercase tracking-tight">Confirm Import?</h4>
              <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">
                {report.total} records will be merged into the master registry.
              </p>
            </div>
            <div className="flex items-center gap-4 w-full md:w-auto">
               <button onClick={reset} className="flex-1 md:flex-none px-10 py-5 text-slate-400 hover:text-white font-black text-[10px] uppercase tracking-widest transition-colors">Cancel</button>
               <button 
                onClick={executeSync}
                disabled={report.total === 0}
                className="flex-1 md:flex-none flex items-center justify-center gap-4 px-16 py-6 bg-indigo-600 text-white rounded-[1.75rem] font-black text-xs uppercase tracking-[0.3em] shadow-xl shadow-indigo-600/20 hover:bg-indigo-500 transition-all active:scale-95 group disabled:opacity-50 disabled:pointer-events-none"
               >
                 <span>Execute Sync</span>
                 <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
               </button>
            </div>
          </div>
        </div>
      )}

      {(status === 'processing' || status === 'parsing') && (
        <div className="flex flex-col items-center justify-center min-h-[500px] space-y-8 animate-in zoom-in-95">
          <div className="relative">
            <div className="w-24 h-24 bg-indigo-50 text-indigo-600 rounded-[2.5rem] flex items-center justify-center shadow-inner">
               <Zap size={44} className="animate-bounce" />
            </div>
            <div className="absolute inset-0 rounded-[2.5rem] border-4 border-indigo-600/10 border-t-indigo-600 animate-spin" />
          </div>
          <div className="text-center">
            <p className="text-2xl font-black text-slate-900 uppercase tracking-tight">
              {status === 'parsing' ? 'Auto-Detecting Columns...' : 'Committing to Registry...'}
            </p>
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.4em] mt-3">Smart Engine Active</p>
          </div>
        </div>
      )}

      {status === 'error' && (
        <div className="p-16 bg-rose-50 border border-rose-100 rounded-[4rem] flex flex-col items-center text-center space-y-8">
          <div className="p-6 bg-rose-500 text-white rounded-3xl shadow-xl">
            <AlertCircle size={48} />
          </div>
          <div className="space-y-3">
            <h3 className="text-2xl font-black text-rose-950 uppercase tracking-tight">Parsing Protocol Failed</h3>
            <p className="text-rose-700 text-[10px] font-black uppercase tracking-[0.3em]">Ensure you are using the official Smart Template provided above.</p>
          </div>
          <button onClick={reset} className="px-10 py-5 bg-white border border-rose-200 text-rose-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all">
            Return to Upload
          </button>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ label, value, color, icon: Icon }: any) => (
  <div className={`p-10 bg-white rounded-[3rem] border border-slate-100 shadow-xl shadow-slate-200/10 flex items-center justify-between group`}>
     <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">{label}</p>
        <p className={`text-3xl font-black text-${color}-600 tracking-tighter tabular-nums`}>{value}</p>
     </div>
     <div className={`p-4 bg-${color}-50 text-${color}-600 rounded-2xl group-hover:scale-110 transition-transform`}>
       <Icon size={28}/>
     </div>
  </div>
);

export default BulkUpload;
