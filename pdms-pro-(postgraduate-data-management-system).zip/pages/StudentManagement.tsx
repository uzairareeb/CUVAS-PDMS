import React, { useState } from 'react';
import { useStore } from '../store';
import { Plus, Search, Edit2, Trash2, Eye, X, Lock, BookOpen, User, Shield, ClipboardList } from 'lucide-react';
import { Student, StudentStatus, Gender, ValidationStatus } from '../types';
import { Link } from 'react-router-dom';

const StudentManagement: React.FC = () => {
  const { students, addStudent, updateStudent, deleteStudent, degrees, departments, settings, currentRole } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const initialFormState: Partial<Student> = {
    name: '', cnic: '', fatherName: '', regNo: '', gender: Gender.MALE, supervisorName: '',
    currentSemester: 1, degree: '', session: settings.institution.admissionSession,
    department: '', programme: '', status: StudentStatus.ACTIVE, validationStatus: ValidationStatus.PENDING,
    gs2CourseWork: 'Not Completed', synopsis: 'Not Submitted', gs4Form: 'Not Submitted',
    contactNumber: '', thesisId: '', semiFinalThesisStatus: 'Not Submitted',
    synopsisSubmissionDate: '', thesisSentToCOE: 'No', comments: '',
  };

  const [formData, setFormData] = useState<Partial<Student>>(initialFormState);

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.regNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.cnic.includes(searchTerm)
  );

  const handleEdit = (student: Student) => {
    if (student.isLocked && !currentRole?.canLockRecords) {
      alert("This secure record is immutable.");
      return;
    }
    setEditingId(student.id);
    setFormData(student);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingId(null);
    setFormData(initialFormState);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.cnic) return;
    
    if (editingId) {
      updateStudent({ ...formData as Student, id: editingId });
    } else {
      addStudent({ ...formData as any });
    }
    closeModal();
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Search & Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 no-print">
        <div className="relative flex-1 max-w-2xl group">
          <div className="absolute inset-0 bg-white rounded-[2rem] shadow-sm border border-slate-100 group-focus-within:border-indigo-600 group-focus-within:ring-4 group-focus-within:ring-indigo-600/5 transition-all" />
          <Search className="absolute left-7 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={22} />
          <input
            type="text"
            placeholder="Search Registry (Name, CNIC, or Reg #)..."
            className="w-full relative z-10 pl-16 pr-8 py-6 bg-transparent border-none outline-none font-bold text-slate-800 placeholder:text-slate-300"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-4 px-12 py-6 bg-[#0a0c10] text-white rounded-[2.25rem] hover:bg-indigo-600 transition-all shadow-2xl shadow-slate-900/10 font-black text-xs uppercase tracking-[0.25em] active:scale-[0.97]"
        >
          <Plus size={22} />
          <span>New Enrollment</span>
        </button>
      </div>

      {/* Main Table Container */}
      <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-xl shadow-slate-200/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-separate border-spacing-0">
            <thead className="bg-slate-50/50 text-slate-400 uppercase text-[9px] font-black tracking-[0.3em]">
              <tr>
                <th className="px-12 py-10 border-b border-slate-100">Scholar Details</th>
                <th className="px-12 py-10 border-b border-slate-100">Programme Details</th>
                <th className="px-12 py-10 border-b border-slate-100">Life Status</th>
                <th className="px-12 py-10 border-b border-slate-100">Audit Status</th>
                <th className="px-12 py-10 border-b border-slate-100 text-right">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map((student) => (
                <tr key={student.id} className="hover:bg-slate-50/30 transition-colors group">
                  <td className="px-12 py-10">
                    <div className="flex items-center space-x-6">
                      <div className="w-14 h-14 rounded-3xl bg-slate-100 flex items-center justify-center text-slate-400 font-black text-2xl group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
                        {student.name[0]}
                      </div>
                      <div>
                        <div className="font-black text-slate-900 text-lg flex items-center tracking-tight">
                          {student.name}
                          {student.isLocked && <Lock size={14} className="ml-2 text-amber-500" />}
                        </div>
                        <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">CNIC: {student.cnic}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-12 py-10">
                    <div>
                      <div className="flex items-center space-x-3">
                        <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-600 text-[9px] font-black uppercase tracking-widest border border-indigo-100">
                          {student.degree}
                        </span>
                        <span className="text-xs font-black text-slate-800 tracking-tight">{student.programme}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-2">{student.regNo} • Sem {student.currentSemester}</div>
                    </div>
                  </td>
                  <td className="px-12 py-10">
                    <span className={`px-5 py-2.5 rounded-[1.25rem] text-[9px] font-black uppercase tracking-[0.15em] border ${
                      student.status === StudentStatus.ACTIVE ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                      student.status === StudentStatus.COMPLETED ? 'bg-indigo-50 text-indigo-600 border-indigo-100' :
                      'bg-slate-100 text-slate-500 border-slate-200'
                    }`}>
                      {student.status}
                    </span>
                  </td>
                  <td className="px-12 py-10">
                    <div className="flex flex-col space-y-1">
                       <span className={`text-[9px] font-black uppercase tracking-widest flex items-center ${
                        student.validationStatus === ValidationStatus.APPROVED ? 'text-emerald-500' :
                        student.validationStatus === ValidationStatus.PENDING ? 'text-amber-500' :
                        'text-rose-500'
                      }`}>
                        <div className={`w-2 h-2 rounded-full mr-3 ${
                           student.validationStatus === ValidationStatus.APPROVED ? 'bg-emerald-500' :
                           student.validationStatus === ValidationStatus.PENDING ? 'bg-amber-500' :
                           'bg-rose-500'
                        }`} />
                        {student.validationStatus}
                      </span>
                    </div>
                  </td>
                  <td className="px-12 py-10">
                    <div className="flex items-center justify-end space-x-4">
                      <Link 
                        to={`/students/${student.id}`}
                        className="p-4 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-2xl transition-all shadow-sm border border-transparent hover:border-slate-100"
                      >
                        <Eye size={20} />
                      </Link>
                      <button 
                        onClick={() => handleEdit(student)}
                        className="p-4 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-2xl transition-all shadow-sm border border-transparent hover:border-slate-100"
                      >
                        <Edit2 size={20} />
                      </button>
                      <button 
                        onClick={() => { if(window.confirm('Confirm Deletion of Record?')) deleteStudent(student.id); }}
                        className="p-4 text-slate-400 hover:text-rose-600 hover:bg-white rounded-2xl transition-all shadow-sm border border-transparent hover:border-slate-100"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Entry Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-8 bg-[#0a0c10]/70 backdrop-blur-xl overflow-y-auto overflow-x-hidden">
          <div className="bg-white rounded-[4rem] w-full max-w-7xl shadow-2xl my-auto overflow-hidden flex flex-col animate-in zoom-in-95 duration-400 border border-white/20">
            <div className="p-14 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-20">
              <div className="flex items-center space-x-8">
                <div className="p-5 bg-[#0a0c10] text-white rounded-[2rem]">
                   <Plus size={32} />
                </div>
                <div>
                  <h3 className="text-3xl font-black text-slate-900 tracking-tight">{editingId ? 'Modify Record' : 'Registry Entry'}</h3>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.4em] mt-2">Institutional High-Security Node</p>
                </div>
              </div>
              <button onClick={closeModal} className="w-16 h-16 flex items-center justify-center text-slate-300 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 rounded-[2rem] transition-all">
                <X size={32} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-14 space-y-16 overflow-y-auto max-h-[70vh]">
               <FormSection title="Legal Identity" icon={User} color="indigo">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
                    <Input label="Name" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
                    <Input label="Father Name" value={formData.fatherName} onChange={v => setFormData({...formData, fatherName: v})} />
                    <Input label="CNIC" value={formData.cnic} onChange={v => setFormData({...formData, cnic: v})} />
                    <Input label="Reg #" value={formData.regNo} onChange={v => setFormData({...formData, regNo: v})} />
                  </div>
               </FormSection>

               <FormSection title="Academic Details" icon={BookOpen} color="indigo">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                    <Select label="Degree" value={formData.degree} options={degrees} onChange={v => setFormData({...formData, degree: v})} />
                    <Select label="Department" value={formData.department} options={departments} onChange={v => setFormData({...formData, department: v})} />
                    <Input label="Programme" value={formData.programme} onChange={v => setFormData({...formData, programme: v})} />
                  </div>
               </FormSection>

               <div className="flex items-center justify-end space-x-8 pt-12 border-t border-slate-100 sticky bottom-0 bg-white/95 backdrop-blur-md pb-6 z-20">
                  <button type="button" onClick={closeModal} className="px-10 py-5 text-slate-400 font-black text-xs uppercase tracking-[0.25em] hover:text-slate-900 transition-colors">Cancel</button>
                  <button type="submit" className="px-16 py-6 bg-[#0a0c10] text-white rounded-[2.5rem] font-black text-xs uppercase tracking-[0.3em] shadow-2xl hover:bg-indigo-600 transition-all">
                    {editingId ? 'Save Updates' : 'Commit Entry'}
                  </button>
               </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const FormSection = ({ title, icon: Icon, children, color }: any) => (
  <div className="space-y-10 animate-in fade-in slide-in-from-left-4 duration-500">
    <h4 className="flex items-center space-x-4 text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 border-b border-slate-50 pb-6">
      <div className={`p-2 bg-${color}-600/10 text-${color}-600 rounded-xl`}>
        <Icon size={18} />
      </div>
      <span>{title}</span>
    </h4>
    <div className="bg-slate-50/40 p-12 rounded-[3.5rem] border border-slate-100/50">
      {children}
    </div>
  </div>
);

const Input = ({ label, value, onChange, type = "text", readOnly = false, placeholder = "" }: any) => (
  <div className="space-y-3">
    <label className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400 ml-2">{label}</label>
    <input 
      type={type}
      readOnly={readOnly}
      placeholder={placeholder}
      className={`w-full px-7 py-5 bg-white border border-slate-200 rounded-[1.5rem] text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all placeholder:text-slate-300 ${readOnly ? 'bg-slate-100 text-slate-500 cursor-not-allowed border-transparent' : ''}`}
      value={value || ''}
      onChange={e => onChange?.(e.target.value)}
    />
  </div>
);

const Select = ({ label, value, options, onChange }: any) => (
  <div className="space-y-3">
    <label className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400 ml-2">{label}</label>
    <div className="relative">
      <select 
        className="w-full px-7 py-5 bg-white border border-slate-200 rounded-[1.5rem] text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all appearance-none cursor-pointer"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        <option value="">-- Choose --</option>
        {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
    </div>
  </div>
);

export default StudentManagement;