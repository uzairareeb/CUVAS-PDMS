
import React from 'react';
import { useStore } from '../store';
import { 
  Search,
  Plus,
  Download,
  FileBarChart,
  History,
  Target,
  LineChart as LineIcon,
  Image as ImageIcon,
  CheckCircle,
  LogOut,
  PauseCircle,
  AlertCircle,
  Layers,
  Zap,
  Users,
  ChevronRight
} from 'lucide-react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Cell, PieChart, Pie, Line, LineChart, Legend
} from 'recharts';
import { StudentStatus, Gender, ValidationStatus } from '../types';
import { useNavigate } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { students, settings } = useStore();
  const navigate = useNavigate();

  // Metric Calculations
  const totalCount = students.length;
  const maleCount = students.filter(s => s.gender === Gender.MALE).length;
  const femaleCount = students.filter(s => s.gender === Gender.FEMALE).length;
  const activeCount = students.filter(s => s.status === StudentStatus.ACTIVE).length;
  const completeCount = students.filter(s => s.status === StudentStatus.COMPLETED).length;
  const leftCount = students.filter(s => s.status === StudentStatus.DROPPED).length;
  const freezeCount = students.filter(s => s.status === StudentStatus.SUSPENDED || s.status === StudentStatus.ON_LEAVE).length;
  const needStatusCount = students.filter(s => s.validationStatus === ValidationStatus.PENDING || s.validationStatus === ValidationStatus.RETURNED).length;

  const kpiGrid = [
    { label: 'Total Scholars', value: totalCount, color: 'text-slate-900', accent: 'bg-slate-900', icon: Layers },
    { label: 'Male Scholars', value: maleCount, color: 'text-blue-900', accent: 'bg-blue-900', icon: Users },
    { label: 'Female Scholars', value: femaleCount, color: 'text-orange-600', accent: 'bg-orange-600', icon: Users },
    { label: 'Active Registry', value: activeCount, color: 'text-emerald-600', accent: 'bg-emerald-600', icon: Zap },
    { label: 'Completed', value: completeCount, color: 'text-indigo-600', accent: 'bg-indigo-600', icon: CheckCircle },
    { label: 'Left / Dropped', value: leftCount, color: 'text-rose-600', accent: 'bg-rose-600', icon: LogOut },
    { label: 'Frozen / Leave', value: freezeCount, color: 'text-sky-500', accent: 'bg-sky-500', icon: PauseCircle },
    { label: 'Pending Audit', value: needStatusCount, color: 'text-amber-500', accent: 'bg-amber-500', icon: AlertCircle },
  ];

  const degreeCounts = students.reduce((acc: any, s) => {
    acc[s.degree] = (acc[s.degree] || 0) + 1;
    return acc;
  }, {});
  const degreePieData = Object.keys(degreeCounts).map(name => ({ name, value: degreeCounts[name] }));

  const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#f43f5e'];

  return (
    <div className="space-y-6 md:space-y-12 animate-in fade-in slide-in-from-top-4 duration-1000 pb-10 md:pb-20">
      
      {/* Institutional Branding Card */}
      <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-12 p-8 md:p-12 bg-white rounded-[2.5rem] md:rounded-[3.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.04)] no-print relative overflow-hidden">
        <div className="absolute top-0 left-0 w-2 md:w-2.5 h-full bg-indigo-600" />
        {settings.institution.logo ? (
          <div className="h-28 w-28 md:h-40 md:w-40 shrink-0 flex items-center justify-center">
            <img 
              src={settings.institution.logo} 
              alt="Institutional Identity" 
              className="max-h-full max-w-full object-contain drop-shadow-2xl transition-transform hover:scale-105 duration-700"
            />
          </div>
        ) : (
          <div className="h-28 w-28 md:h-40 md:w-40 rounded-[2rem] md:rounded-[2.5rem] bg-slate-50 border border-slate-100 flex flex-col items-center justify-center text-slate-300">
            <ImageIcon size={32} />
            <span className="text-[7px] font-black uppercase mt-1 tracking-tighter">Null Identity</span>
          </div>
        )}
        
        <div className="hidden md:block h-32 w-px bg-slate-100" />
        
        <div className="space-y-4 md:space-y-3 text-center md:text-left flex-1">
          <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight uppercase drop-shadow-sm">
            {settings.institution.name}
          </h2>
          <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-3 md:gap-4">
             <p className="text-[10px] md:text-[12px] font-black text-slate-400 uppercase tracking-[0.4em]">
                {settings.institution.directorate}
             </p>
             <div className="hidden sm:block w-1.5 h-1.5 rounded-full bg-indigo-200" />
             <p className="text-[8px] md:text-[10px] font-black text-indigo-600 uppercase tracking-widest bg-indigo-50 px-4 md:px-5 py-1.5 md:py-2 rounded-full border border-indigo-100/50">PDMS-PRO v4.0 Registry</p>
          </div>
        </div>
      </div>

      {/* Metric Grid - Font size reduced 20% (from 4xl/6xl to 3xl/5xl) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-8 no-print">
        {kpiGrid.map((item, idx) => (
          <div 
            key={idx} 
            className="group relative flex flex-col bg-white rounded-2xl md:rounded-[2.5rem] overflow-hidden transition-all duration-500 hover:-translate-y-2 shadow-[0_8px_30px_rgba(0,0,0,0.03)] hover:shadow-[0_40px_80px_-15px_rgba(15,23,42,0.15)]"
          >
            <div className={`h-1 w-full ${item.accent} opacity-10 group-hover:opacity-100 transition-all duration-700`} />
            <div className="relative p-5 md:p-10 flex flex-col items-center justify-center space-y-1">
               <span className="text-[7px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] text-slate-400 group-hover:text-slate-900 text-center">
                  {item.label}
               </span>
               <span className="text-2xl md:text-5xl font-[900] text-slate-900 tracking-tighter tabular-nums transition-all">
                  {item.value}
               </span>
               <div className={`h-1 w-6 md:w-8 rounded-full ${item.accent} opacity-10 group-hover:w-16 transition-all duration-700 mt-2`} />
            </div>
          </div>
        ))}
      </div>

      {/* Intelligence Controls */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 md:gap-10 no-print px-2 md:px-4">
        <div className="space-y-1">
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight uppercase">Master Intelligence</h1>
          <p className="text-slate-400 text-xs md:text-sm font-medium tracking-tight">Real-time monitoring and scholar lifecycle analytics.</p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 w-full xl:w-auto">
          <div className="relative group w-full sm:min-w-[300px] md:min-w-[360px]">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Query Scholar Registry..."
              className="w-full pl-14 pr-8 py-4 md:py-5 bg-white rounded-2xl md:rounded-[2rem] shadow-sm border border-slate-100 outline-none focus:ring-8 focus:ring-indigo-600/5 focus:border-indigo-600 font-bold text-sm transition-all"
              onClick={() => navigate('/records')}
            />
          </div>
          <button 
            onClick={() => navigate('/registration')}
            className="w-full sm:w-auto px-10 md:px-12 py-4 md:py-5 bg-[#0f172a] text-white rounded-2xl md:rounded-[2rem] font-black text-[10px] md:text-xs uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all flex items-center justify-center shadow-lg active:scale-95 group"
          >
            <Plus size={18} className="mr-3 group-hover:rotate-90 transition-transform duration-500" />
            <span>Provision Entry</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-10">
        {/* Velocity Trends */}
        <div className="lg:col-span-8 bg-white p-6 md:p-14 rounded-[2.5rem] md:rounded-[4.5rem] shadow-[0_20px_60px_rgba(0,0,0,0.03)] border border-slate-50 overflow-hidden group">
          <div className="flex items-center justify-between mb-8 md:mb-12">
            <div>
              <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight uppercase flex items-center">
                <LineIcon size={24} className="mr-4 text-indigo-600" />
                Performance Velocity
              </h3>
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.4em] mt-2">Scholar lifecycle trends</p>
            </div>
          </div>
          <div className="h-[250px] md:h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={[
                { semester: 'Sem 1', PhD: 45, MPhil: 32 },
                { semester: 'Sem 2', PhD: 52, MPhil: 40 },
                { semester: 'Sem 3', PhD: 48, MPhil: 55 },
                { semester: 'Sem 4', PhD: 61, MPhil: 59 },
                { semester: 'Sem 5', PhD: 75, MPhil: 70 },
                { semester: 'Sem 6', PhD: 88, MPhil: 82 },
              ]}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="semester" axisLine={false} tickLine={false} tick={{fontSize: 9, fontWeight: 900, fill: '#94a3b8'}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 9, fontWeight: 900, fill: '#94a3b8'}} />
                <Tooltip 
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 40px rgba(0,0,0,0.1)', background: '#fff'}}
                  labelStyle={{fontWeight: 900, fontSize: '11px', color: '#0f172a'}}
                />
                <Legend verticalAlign="top" align="right" iconType="circle" />
                <Line type="monotone" dataKey="PhD" stroke="#6366f1" strokeWidth={4} dot={{ r: 4, fill: '#6366f1' }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="MPhil" stroke="#a855f7" strokeWidth={4} dot={{ r: 4, fill: '#a855f7' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Action Protocols */}
        <div className="lg:col-span-4 space-y-6 md:space-y-10">
          <div className="bg-[#0f172a] p-8 md:p-12 rounded-[2.5rem] md:rounded-[4rem] text-white shadow-2xl relative overflow-hidden group">
            <h3 className="text-lg font-black tracking-tight mb-8 uppercase flex items-center">
               <Target size={20} className="mr-3 text-indigo-400" />
               Command Center
            </h3>
            <div className="space-y-4">
              <QuickAction icon={Plus} label="Enroll Scholar" path="/registration" />
              <QuickAction icon={Download} label="Data Extraction" path="/export" />
              <QuickAction icon={FileBarChart} label="Report Suite" path="/reports" />
              <QuickAction icon={History} label="Audit Logs" path="/audit" />
            </div>
          </div>

          <div className="bg-white p-8 md:p-12 rounded-[2.5rem] md:rounded-[3.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.03)] border border-slate-50 flex flex-col items-center group">
            <h3 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] mb-8">Degree Distribution</h3>
            <div className="h-[200px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={degreePieData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={8} dataKey="value">
                    {degreePieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{borderRadius: '16px', border: 'none', fontWeight: 900, fontSize: '10px'}} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter transition-all">{students.length}</span>
                <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Total</span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

const QuickAction = ({ icon: Icon, label, path }: any) => {
  const navigate = useNavigate();
  return (
    <button 
      onClick={() => navigate(path)}
      className="w-full group flex items-center justify-between p-4 md:p-6 bg-white/5 border border-white/10 rounded-2xl md:rounded-[2.25rem] hover:bg-indigo-600 hover:border-indigo-400 transition-all text-left"
    >
      <div className="flex items-center space-x-4">
        <div className="p-2.5 bg-indigo-500/20 text-indigo-400 rounded-xl group-hover:bg-white/20 group-hover:text-white transition-colors">
          <Icon size={16} />
        </div>
        <span className="text-[10px] md:text-[11px] font-black uppercase tracking-widest leading-none">{label}</span>
      </div>
      <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
    </button>
  );
};

export default Dashboard;
