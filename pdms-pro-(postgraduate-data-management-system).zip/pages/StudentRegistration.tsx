
import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  User, 
  ClipboardList, 
  BookOpen, 
  Save, 
  CheckCircle2, 
  AlertCircle,
  ChevronRight,
  Info
} from 'lucide-react';
import { Student, StudentStatus, Gender, ValidationStatus } from '../types';
import Autocomplete from '../components/Autocomplete';

type RegistrationTab = 'identity' | 'supervision' | 'thesis';

const StudentRegistration: React.FC = () => {
  const { addStudent, degrees, programmes, faculty, settings } = useStore();
  const [activeTab, setActiveTab] = useState<RegistrationTab>('identity');
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(false);

  const initialFormState: Partial<Student> = {
    cnic: '', name: '', fatherName: '', regNo: '', gender: Gender.MALE, contactNumber: '',
    degree: 'M.Phil', session: settings.institution.admissionSession, programme: '',
    currentSemester: 1, status: StudentStatus.ACTIVE, supervisorName: '', coSupervisor: '',
    member1: '', member2: '',
    thesisId: '', synopsis: 'Not Submitted', synopsisSubmissionDate: '',
    gs2CourseWork: 'Not Completed', gs4Form: 'Not Submitted', 
    semiFinalThesisStatus: 'Not Submitted', semiFinalThesisSubmissionDate: '',
    finalThesisStatus: 'Not Submitted', finalThesisSubmissionDate: '', thesisSentToCOE: 'No',
    coeSubmissionDate: '', validationStatus: ValidationStatus.PENDING, validationDate: '', comments: ''
  };

  const [formData, setFormData] = useState<Partial<Student>>(initialFormState);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.cnic || !formData.regNo) {
      setError(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    addStudent(formData as any);
    setSuccess(true);
    setError(false);
    setFormData(initialFormState);
    setActiveTab('identity');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => setSuccess(false), 5000);
  };

  const tabs: { id: RegistrationTab; label: string; icon: any }[] = [
    { id: 'identity', label: 'Identity & Academics', icon: User },
    { id: 'supervision', label: 'Supervisory Committee', icon: BookOpen },
    { id: 'thesis', label: 'Dissertation & COE', icon: ClipboardList },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20 px-4">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-4xl font-black text-slate-900 tracking-tight uppercase">New Student Registration</h1>
        <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.3em]">Add a new student to the postgraduate database</p>
      </div>

      {success && (
        <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-[2.5rem] flex items-center space-x-5 shadow-lg shadow-emerald-500/5 animate-in slide-in-from-top-4">
          <div className="p-3 bg-emerald-500 text-white rounded-2xl shadow-lg shadow-emerald-500/20">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-sm font-black text-emerald-900 uppercase tracking-widest">Registration Successful</p>
            <p className="text-xs font-bold text-emerald-700 uppercase tracking-tighter mt-0.5">The student record has been saved to the registry.</p>
          </div>
        </div>
      )}

      {error && (
        <div className="p-6 bg-rose-50 border border-rose-100 rounded-[2.5rem] flex items-center space-x-5 shadow-lg shadow-rose-500/5 animate-in slide-in-from-top-4">
          <div className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-500/20">
            <AlertCircle size={24} />
          </div>
          <div>
            <p className="text-sm font-black text-rose-900 uppercase tracking-widest">Incomplete Information</p>
            <p className="text-xs font-bold text-rose-700 uppercase tracking-tighter mt-0.5">Please provide the required fields: CNIC, Student Name, and Reg #.</p>
          </div>
        </div>
      )}

      {/* Main Registration Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Sidebar: Guide Card */}
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl shadow-slate-200/30 flex flex-col relative overflow-hidden group">
             <div className="absolute top-0 inset-x-0 h-2 bg-indigo-600" />
             <div className="p-5 bg-indigo-50 text-indigo-600 rounded-3xl w-fit mb-8 shadow-inner">
               <Info size={32} />
             </div>
             <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase leading-tight">Data Entry Guide</h2>
             <p className="text-slate-500 text-sm font-medium mt-4 leading-relaxed">
               Please fill in all information carefully. Fields marked with <span className="text-rose-500 font-bold">*</span> are required. Use the tabs on the right to navigate through different sections of the registration form.
             </p>
             
             <div className="w-full mt-10 pt-8 border-t border-slate-50 space-y-6">
                {tabs.map((tab, idx) => (
                  <div key={tab.id} className={`flex items-center space-x-4 transition-all ${activeTab === tab.id ? 'opacity-100 scale-105' : 'opacity-40'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-[10px] ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-400'}`}>
                      {idx + 1}
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-900">{tab.label}</span>
                  </div>
                ))}
             </div>
          </div>

          <div className="bg-[#0f172a] p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
             <div className="absolute -right-4 -bottom-4 text-white opacity-5 rotate-12"><Save size={120} /></div>
             <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400 mb-6">Action Protocol</h3>
             <p className="text-slate-400 text-xs font-medium leading-relaxed mb-10 relative z-10">
               Click the button below once all tabs are completed to finalize the registration.
             </p>
             <button 
               onClick={handleSubmit}
               className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-[0.3em] shadow-xl shadow-indigo-600/20 hover:bg-indigo-500 transition-all flex items-center justify-center space-x-4 group relative z-10"
             >
               <Save size={18} />
               <span>Register Student</span>
             </button>
          </div>
        </div>

        {/* Right Area: Tabs & Form Content */}
        <div className="lg:col-span-8 flex flex-col space-y-8">
          
          {/* Tab Selection Bar */}
          <div className="bg-white p-2 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-wrap gap-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 min-w-[160px] flex items-center justify-center space-x-3 py-5 px-6 rounded-[1.75rem] font-black text-[10px] uppercase tracking-widest transition-all duration-300 ${
                    isActive 
                      ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/20 translate-y-[-2px]' 
                      : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Form Content Pane */}
          <div className="bg-white p-8 md:p-14 rounded-[4rem] border border-slate-100 shadow-xl shadow-slate-200/40 min-h-[600px]">
            <form onSubmit={handleSubmit} className="space-y-12">
              
              {/* Tab 1: Personal & Academic */}
              {activeTab === 'identity' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-10">
                  <div className="flex items-center space-x-4 border-b border-slate-50 pb-6">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><User size={24} /></div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-[0.4em]">Personal Information</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Input label="CNIC Number" value={formData.cnic} onChange={v => setFormData({...formData, cnic: v})} required placeholder="Enter CNIC (e.g. 00000-0000000-0)" />
                    <Input label="Student Name" value={formData.name} onChange={v => setFormData({...formData, name: v})} required placeholder="Enter Full Name" />
                    <Input label="Father's Name" value={formData.fatherName} onChange={v => setFormData({...formData, fatherName: v})} placeholder="Enter Father's Name" />
                    <Input label="Registration Number" value={formData.regNo} onChange={v => setFormData({...formData, regNo: v})} required placeholder="Enter University Reg #" />
                    <Select label="Gender" value={formData.gender} options={['Male', 'Female']} onChange={v => setFormData({...formData, gender: v as any})} />
                    <Input label="Contact Number" value={formData.contactNumber} onChange={v => setFormData({...formData, contactNumber: v})} placeholder="Mobile/Phone Number" />
                    <Select label="Degree Type" value={formData.degree} options={degrees} onChange={v => setFormData({...formData, degree: v})} />
                    <Input label="Session" value={formData.session} onChange={v => setFormData({...formData, session: v})} placeholder="e.g. Spring 2026" />
                    <Select label="Study Program" value={formData.programme} options={programmes} onChange={v => setFormData({...formData, programme: v})} />
                    <Input label="Current Semester" type="number" value={formData.currentSemester?.toString()} onChange={v => setFormData({...formData, currentSemester: parseInt(v)})} />
                    <Select label="Current Status" value={formData.status} options={['Active', 'On Leave', 'Closed']} onChange={v => setFormData({...formData, status: v as any})} />
                  </div>
                  <div className="flex justify-end pt-8">
                    <button type="button" onClick={() => setActiveTab('supervision')} className="flex items-center space-x-3 px-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all">
                      <span>Next: Supervision</span>
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              )}

              {/* Tab 2: Supervision & Committee */}
              {activeTab === 'supervision' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-10">
                  <div className="flex items-center space-x-4 border-b border-slate-50 pb-6">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><BookOpen size={24} /></div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-[0.4em]">Supervision & Committee</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Autocomplete label="Main Supervisor" value={formData.supervisorName || ''} suggestions={faculty} onChange={v => setFormData({...formData, supervisorName: v})} required placeholder="Search faculty name..." />
                    <Input label="Co-Supervisor" value={formData.coSupervisor || ''} onChange={v => setFormData({...formData, coSupervisor: v})} placeholder="Enter Co-Supervisor Name" />
                    <Autocomplete label="Committee Member 1" value={formData.member1 || ''} suggestions={faculty} onChange={v => setFormData({...formData, member1: v})} placeholder="Search faculty name..." />
                    <Autocomplete label="Committee Member 2" value={formData.member2 || ''} suggestions={faculty} onChange={v => setFormData({...formData, member2: v})} placeholder="Search faculty name..." />
                    <Input label="Thesis ID / Research ID" value={formData.thesisId} onChange={v => setFormData({...formData, thesisId: v})} placeholder="Unique Research Identifier" />
                    <div className="hidden md:block" />
                    <Select label="Synopsis Status" value={formData.synopsis} options={['Not Submitted', 'Submitted', 'Approved']} onChange={v => setFormData({...formData, synopsis: v as any, synopsisSubmissionDate: v === 'Not Submitted' ? '' : formData.synopsisSubmissionDate})} />
                    <Input label="Synopsis Date" type="date" value={formData.synopsisSubmissionDate} onChange={v => setFormData({...formData, synopsisSubmissionDate: v})} disabled={formData.synopsis === 'Not Submitted'} />
                    <Select label="Coursework Status (GS-2)" value={formData.gs2CourseWork} options={['Not Completed', 'Completed']} onChange={v => setFormData({...formData, gs2CourseWork: v as any})} />
                    <Select label="Form Progress (GS-4)" value={formData.gs4Form} options={['Not Submitted', 'Submitted', 'Approved']} onChange={v => setFormData({...formData, gs4Form: v as any})} />
                  </div>
                  <div className="flex justify-between pt-8">
                    <button type="button" onClick={() => setActiveTab('identity')} className="flex items-center space-x-3 px-8 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all">
                      <span>Back: Personal Info</span>
                    </button>
                    <button type="button" onClick={() => setActiveTab('thesis')} className="flex items-center space-x-3 px-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all">
                      <span>Next: Thesis Details</span>
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              )}

              {/* Tab 3: Thesis & Results */}
              {activeTab === 'thesis' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-10">
                  <div className="flex items-center space-x-4 border-b border-slate-50 pb-6">
                    <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><ClipboardList size={24} /></div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-[0.4em]">Thesis & Office Records</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Select label="Semi-Final Thesis Status" value={formData.semiFinalThesisStatus} options={['Not Submitted', 'Submitted', 'Approved']} onChange={v => setFormData({...formData, semiFinalThesisStatus: v as any})} />
                    <Input label="Semi-Final Submission Date" type="date" value={formData.semiFinalThesisSubmissionDate} onChange={v => setFormData({...formData, semiFinalThesisSubmissionDate: v})} disabled={formData.semiFinalThesisStatus === 'Not Submitted'} />
                    <Select label="Final Thesis Status" value={formData.finalThesisStatus} options={['Not Submitted', 'Submitted', 'Approved']} onChange={v => setFormData({...formData, finalThesisStatus: v as any})} />
                    <Input label="Final Submission Date" type="date" value={formData.finalThesisSubmissionDate} onChange={v => setFormData({...formData, finalThesisSubmissionDate: v})} disabled={formData.finalThesisStatus === 'Not Submitted'} />
                    <Select label="Sent to COE Office" value={formData.thesisSentToCOE} options={['No', 'Yes']} onChange={v => setFormData({...formData, thesisSentToCOE: v as any})} />
                    <Input label="COE Dispatch Date" type="date" value={formData.coeSubmissionDate} onChange={v => setFormData({...formData, coeSubmissionDate: v})} disabled={formData.thesisSentToCOE === 'No'} />
                    <Select label="Audit Validation Status" value={formData.validationStatus} options={['Pending', 'Approved']} onChange={v => setFormData({...formData, validationStatus: v as any})} />
                    <Input label="Validation Date" type="date" value={formData.validationDate} onChange={v => setFormData({...formData, validationDate: v})} disabled={formData.validationStatus === 'Pending'} />
                    <div className="md:col-span-2">
                       <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 ml-1 mb-3 block">Office Comments / Remarks</label>
                       <textarea 
                          className="w-full px-8 py-6 bg-slate-50 border border-slate-200 rounded-[2rem] text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all min-h-[150px]"
                          value={formData.comments}
                          onChange={e => setFormData({...formData, comments: e.target.value})}
                          placeholder="Enter any additional office notes or scholar progress remarks..."
                       />
                    </div>
                  </div>
                  <div className="flex justify-between pt-8">
                    <button type="button" onClick={() => setActiveTab('supervision')} className="flex items-center space-x-3 px-8 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all">
                      <span>Back: Supervision</span>
                    </button>
                    <button type="submit" className="flex items-center space-x-4 px-16 py-5 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-[0.3em] shadow-2xl hover:bg-indigo-500 transition-all active:scale-95 group">
                      <Save size={20} className="group-hover:rotate-12 transition-transform" />
                      <span>Register Student</span>
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

const Input = ({ label, value, onChange, type = "text", required = false, disabled = false, placeholder = "" }: any) => (
  <div className="space-y-3">
    <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 ml-2 block">
      {label} {required && <span className="text-rose-500">*</span>}
    </label>
    <input 
      type={type}
      disabled={disabled}
      placeholder={placeholder}
      className={`w-full px-7 py-5 bg-slate-50 border border-slate-200 rounded-[1.5rem] text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all placeholder:text-slate-300 ${disabled ? 'opacity-30 cursor-not-allowed bg-slate-100' : 'hover:border-slate-300'}`}
      value={value || ''}
      onChange={e => onChange?.(e.target.value)}
    />
  </div>
);

const Select = ({ label, value, options, onChange }: any) => (
  <div className="space-y-3">
    <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 ml-2 block">{label}</label>
    <div className="relative">
      <select 
        className="w-full px-7 py-5 bg-slate-50 border border-slate-200 rounded-[1.5rem] text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all appearance-none cursor-pointer hover:border-slate-300"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        <option value="">-- Choose Option --</option>
        {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
      <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-slate-300">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
      </div>
    </div>
  </div>
);

export default StudentRegistration;
