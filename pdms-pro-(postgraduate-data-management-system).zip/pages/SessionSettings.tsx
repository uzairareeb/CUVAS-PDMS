
import React, { useState } from 'react';
import { useStore } from '../store';
import { Calendar, Plus, Save, Clock } from 'lucide-react';
import { SessionConfig } from '../types';

const SessionSettings: React.FC = () => {
  const { sessions, addSession, settings } = useStore();
  const [newSession, setNewSession] = useState<Partial<SessionConfig>>({
    name: 'Fall 2026',
    startDate: '2026-09-01'
  });

  const handleAdd = () => {
    if (!newSession.name || !newSession.startDate) return;
    
    // Generate semesters based on settings duration
    const semesters = Array.from({ length: 8 }, (_, i) => {
      const start = new Date(newSession.startDate!);
      start.setMonth(start.getMonth() + (i * 6)); // Rough estimate
      const end = new Date(start);
      // Fixed: Use standard setDate logic to add duration in weeks.
      // This avoids non-standard prototype methods and handles rollovers correctly.
      end.setDate(end.getDate() + (settings.defaultSemesterDurationWeeks * 7));
      
      return {
        number: i + 1,
        start: start.toISOString().split('T')[0],
        end: end.toISOString().split('T')[0],
      };
    });

    addSession({
      id: Math.random().toString(36).substr(2, 9),
      name: newSession.name,
      startDate: newSession.startDate,
      semesters: semesters as any
    });
  };

  return (
    <div className="space-y-8 max-w-5xl">
      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
        <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center">
          <Plus size={20} className="mr-2 text-blue-600" />
          Define New Academic Session
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1 text-[10px] uppercase font-bold text-slate-400">Session Name</label>
            <input 
              type="text" 
              placeholder="e.g. Fall 2026"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
              value={newSession.name}
              onChange={e => setNewSession({...newSession, name: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1 text-[10px] uppercase font-bold text-slate-400">Commencement Date</label>
            <input 
              type="date" 
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
              value={newSession.startDate}
              onChange={e => setNewSession({...newSession, startDate: e.target.value})}
            />
          </div>
        </div>
        <div className="mt-6 pt-6 border-t border-slate-100">
          <button 
            onClick={handleAdd}
            className="flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-bold transition-all shadow-lg shadow-blue-500/30"
          >
            <Save size={18} />
            <span>Create Session & Auto-generate Semesters</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {sessions.map(session => (
          <div key={session.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 bg-slate-800 text-white flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Calendar size={24} className="text-blue-400" />
                <h3 className="text-lg font-bold">{session.name}</h3>
              </div>
              <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Commenced: {session.startDate}</span>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {session.semesters.map(sem => (
                  <div key={sem.number} className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <h4 className="text-sm font-bold text-slate-900 mb-2 flex items-center">
                      <Clock size={14} className="mr-1.5 text-blue-500" />
                      Semester {sem.number}
                    </h4>
                    <div className="text-[11px] text-slate-500">
                      <p>Start: {sem.start}</p>
                      <p>End: {sem.end}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SessionSettings;
