
import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Search, Eye, Edit2, Trash2, Lock, Unlock, 
  X, User, Filter, RotateCcw, ChevronDown, ShieldAlert,
  MapPin, Briefcase, ChevronRight, GraduationCap, LayoutGrid, CheckCircle2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Student, StudentStatus, ValidationStatus } from '../types';

const StudentRecords: React.FC = () => {
  const { students, deleteStudent, toggleLockStudent, currentRole, departments } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter States
  const [filterDegree, setFilterDegree] = useState<string>('');
  const [filterDept, setFilterDept] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [filterValidation, setFilterValidation] = useState<string>('');
  
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [previewStudent, setPreviewStudent] = useState<Student | null>(null);
  
  const resetFilters = () => {
    setSearchTerm('');
    setFilterDegree('');
    setFilterDept('');
    setFilterStatus('');
    setFilterValidation('');
  };

  // Helper for dot-agnostic degree comparison
  const normalizeDegree = (val: string) => val.replace(/\./g, '').trim().toUpperCase();

  const filtered = students.filter(s => {
    const searchStr = searchTerm.toLowerCase();
    const matchesSearch = s.name.toLowerCase().includes(searchStr) ||
      s.regNo.toLowerCase().includes(searchStr) ||
      s.cnic.includes(searchStr) ||
      s.programme.toLowerCase().includes(searchStr) ||
      s.supervisorName.toLowerCase().includes(searchStr);
    
    const matchesDegree = filterDegree === '' || normalizeDegree(s.degree) === normalizeDegree(filterDegree);
    const matchesDept = filterDept === '' || s.department === filterDept;
    const matchesStatus = filterStatus === '' || s.status === filterStatus;
    const matchesValidation = filterValidation === '' || s.validationStatus === filterValidation;

    return matchesSearch && matchesDegree && matchesDept && matchesStatus && matchesValidation;
  });

  const handleToggleLock = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    toggleLockStudent(id);
  };

  const hasActiveFilters = filterDegree || filterDept || filterStatus || filterValidation || searchTerm;

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-700 relative pb-20 max-w-full">
      {/* Header - Adaptive Scaling */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 no-print px-1 md:px-2">
        <div className="space-y-1.5">
          <div className="flex items-center space-x-3">
             <div className="p-2.5 bg-indigo-600 rounded-2xl text-white shadow-lg shadow-indigo-600/20">
                <LayoutGrid size={22} />
             </div>
             <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight uppercase">Scholar Registry</h1>
          </div>
          <p className="text-slate-400 text-[9px] md:text-[10px] font-bold uppercase tracking-[0.2em] ml-1">Institutional Student Progress Monitoring</p>
        </div>
        
        <div className="flex items-center justify-between md:justify-end gap-3 md:gap-4 border-t md:border-t-0 pt-4 md:pt-0">
           <div className="flex flex-col items-start md:items-end">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Global Coverage</span>
              <span className="text-lg md:text-xl font-black text-indigo-600 tabular-nums">{filtered.length} / {students.length}</span>
           </div>
           <div className="h-10 w-px bg-slate-200 hidden md:block" />
           <button 
             onClick={() => window.print()}
             className="px-5 py-2.5 bg-white border border-slate-200 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all shadow-sm active:scale-95"
           >
             Print View
           </button>
        </div>
      </div>

      {/* Responsive Filter System */}
      <div className="bg-white p-5 md:p-8 lg:p-10 rounded-[2rem] md:rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 space-y-6 md:space-y-8 no-print">
        <div className="flex flex-col lg:flex-row gap-4 md:gap-6">
          <div className="relative group flex-1">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={18} />
            <input 
              type="text"
              className="w-full pl-14 pr-6 py-4 md:py-5 bg-slate-50 border border-slate-200 rounded-2xl md:rounded-[1.75rem] outline-none focus:ring-8 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all font-bold text-sm placeholder:text-slate-300"
              placeholder="Search Scholar Name, ID, or Program..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>

          <button 
            onClick={resetFilters}
            disabled={!hasActiveFilters}
            className={`flex items-center justify-center space-x-3 px-8 py-4 md:py-5 rounded-2xl md:rounded-[1.75rem] font-black text-[10px] uppercase tracking-widest transition-all ${
              hasActiveFilters 
              ? 'bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white border border-rose-100' 
              : 'bg-slate-50 text-slate-300 cursor-not-allowed'
            }`}
          >
            <RotateCcw size={16} />
            <span>Reset</span>
          </button>
        </div>

        {/* 1 col on Mobile, 2 on Tablet, 4 on Laptop/PC */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <FilterSelect 
            label="Degree Type" 
            value={filterDegree} 
            icon={GraduationCap}
            options={['M.Phil', 'PhD']} 
            displayOptions={['MPhil', 'PHD']}
            onChange={setFilterDegree} 
          />
          <FilterSelect 
            label="Specialization" 
            value={filterDept} 
            icon={MapPin}
            options={departments} 
            onChange={setFilterDept} 
          />
          <FilterSelect 
            label="Status" 
            value={filterStatus} 
            icon={Briefcase}
            options={Object.values(StudentStatus)} 
            onChange={setFilterStatus} 
          />
          <FilterSelect 
            label="Validation" 
            value={filterValidation} 
            icon={CheckCircle2}
            options={Object.values(ValidationStatus)} 
            onChange={setFilterValidation} 
          />
        </div>
      </div>

      {/* Main Content Area - Adaptive Display */}
      <div className="bg-white rounded-[2rem] md:rounded-[3.5rem] border border-slate-100 shadow-2xl shadow-slate-200/40 overflow-hidden">
        
        {/* Mobile: Card Layout (Hidden on Laptop/Tablet) */}
        <div className="md:hidden divide-y divide-slate-100">
           {filtered.map(student => (
             <div 
               key={student.id} 
               onClick={() => setPreviewStudent(student)}
               className="p-6 flex flex-col space-y-4 hover:bg-slate-50 active:bg-indigo-50 transition-colors"
             >
                <div className="flex items-center justify-between">
                   <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg ${student.isLocked ? 'bg-amber-100 text-amber-600' : 'bg-indigo-600 text-white'}`}>
                        {student.isLocked ? <Lock size={18} /> : student.name[0]}
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-base leading-none">{student.name}</h4>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{student.regNo}</p>
                      </div>
                   </div>
                   <div className="p-2 text-slate-300"><ChevronRight size={18} /></div>
                </div>
                <div className="flex items-center justify-between gap-2">
                   <div className="flex-1 flex flex-col">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Program</span>
                      <span className="text-[11px] font-bold text-slate-700 truncate">{student.degree} {student.programme}</span>
                   </div>
                   <div className="shrink-0 flex flex-col items-end">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Status</span>
                      <span className={`px-2 py-0.5 rounded-lg text-[8px] font-black uppercase border ${
                        student.status === StudentStatus.ACTIVE ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-50 text-slate-500 border-slate-200'
                      }`}>
                        {student.status}
                      </span>
                   </div>
                </div>
             </div>
           ))}
        </div>

        {/* Laptop/Tablet: Table Layout (Hidden on Mobile) */}
        <div className="hidden md:block overflow-x-auto custom-scrollbar">
          <table className="w-full text-left text-sm border-separate border-spacing-0 min-w-full">
            <thead className="bg-slate-50/50 text-slate-400 uppercase text-[9px] font-black tracking-[0.25em]">
              <tr>
                <th className="px-6 md:px-10 py-8 md:py-10 border-b border-slate-100">Scholar Details</th>
                <th className="px-6 md:px-10 py-8 md:py-10 border-b border-slate-100 hidden lg:table-cell">Placement</th>
                <th className="px-6 md:px-10 py-8 md:py-10 border-b border-slate-100">Status Node</th>
                <th className="px-6 md:px-10 py-8 md:py-10 border-b border-slate-100 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(student => (
                <tr 
                  key={student.id} 
                  onClick={() => setPreviewStudent(student)}
                  className={`cursor-pointer hover:bg-slate-50/50 transition-colors group ${student.isLocked ? 'bg-amber-50/15' : ''} ${previewStudent?.id === student.id ? 'bg-indigo-50/60' : ''}`}
                >
                  <td className="px-6 md:px-10 py-6 md:py-8">
                    <div className="flex items-center space-x-4 md:space-x-6">
                      <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center font-black text-lg md:text-xl transition-all shadow-sm ${
                        student.isLocked 
                        ? 'bg-amber-100 text-amber-600' 
                        : (previewStudent?.id === student.id ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-300 group-hover:bg-indigo-600 group-hover:text-white')
                      }`}>
                        {student.isLocked ? <Lock size={20} /> : student.name[0]}
                      </div>
                      <div className="min-w-0">
                        <div className="font-black text-slate-900 text-base md:text-lg flex items-center tracking-tight truncate leading-none">
                          {student.name}
                        </div>
                        <p className="text-[9px] md:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 md:mt-2 truncate">{student.regNo}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 md:px-10 py-6 md:py-8 hidden lg:table-cell">
                    <div className="min-w-0">
                      <div className="flex items-center space-x-3 truncate">
                         <span className="px-2 py-1 bg-indigo-50 text-indigo-600 text-[9px] font-black uppercase rounded-lg border border-indigo-100 shrink-0">{student.degree}</span>
                         <span className="text-[11px] font-black text-slate-800 uppercase tracking-tighter truncate">{student.programme}</span>
                      </div>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-2 truncate">{student.department}</p>
                    </div>
                  </td>
                  <td className="px-6 md:px-10 py-6 md:py-8">
                    <div className="flex flex-col space-y-2">
                        <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border w-fit ${
                          student.status === StudentStatus.ACTIVE ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                          student.status === StudentStatus.COMPLETED ? 'bg-indigo-50 text-indigo-600 border-indigo-100' :
                          'bg-slate-100 text-slate-500 border-slate-200'
                        }`}>
                          {student.status}
                        </span>
                        <span className={`text-[8px] md:text-[9px] font-black uppercase tracking-widest flex items-center ${
                          student.validationStatus === ValidationStatus.APPROVED ? 'text-emerald-500' : 'text-amber-500'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full mr-2 ${student.validationStatus === ValidationStatus.APPROVED ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                          {student.validationStatus}
                        </span>
                    </div>
                  </td>
                  <td className="px-6 md:px-10 py-6 md:py-8 text-right">
                    <div className="flex items-center justify-end space-x-2 md:space-x-3">
                      <Link 
                        to={`/students/${student.id}`}
                        onClick={(e) => e.stopPropagation()}
                        className="p-3 text-slate-300 hover:text-indigo-600 hover:bg-white rounded-xl transition-all shadow-sm border border-transparent hover:border-slate-100"
                      >
                        <Eye size={18} />
                      </Link>
                      <button 
                        onClick={(e) => handleToggleLock(e, student.id)}
                        className={`p-3 rounded-xl transition-all shadow-sm border border-transparent ${
                          student.isLocked ? 'text-amber-600 bg-amber-50' : 'text-slate-300 hover:text-amber-500 hover:bg-white'
                        }`}
                      >
                        {student.isLocked ? <Lock size={18} /> : <Unlock size={18} />}
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); setDeletingId(student.id); }}
                        className="p-3 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all shadow-sm"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Empty State */}
        {filtered.length === 0 && (
          <div className="py-24 md:py-32 text-center flex flex-col items-center justify-center space-y-6">
            <div className="p-10 md:p-12 bg-slate-50 text-slate-200 rounded-[3rem] md:rounded-[4rem]">
              <Search size={60} className="md:w-20 md:h-20" />
            </div>
            <div>
              <p className="text-xl md:text-2xl font-black text-slate-900 uppercase tracking-tight">Empty Registry Segment</p>
              <p className="text-slate-400 text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] mt-2">Try adjusting your filters or search query.</p>
            </div>
          </div>
        )}
      </div>

      {/* Snapshot Sidebar - Balanced for Tablet and Mobile */}
      {previewStudent && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[60] no-print" onClick={() => setPreviewStudent(null)}>
           <div 
             className={`absolute top-0 right-0 h-full w-full sm:w-[450px] bg-white shadow-2xl transition-transform duration-500 ease-out flex flex-col ${previewStudent ? 'translate-x-0' : 'translate-x-full'}`}
             onClick={e => e.stopPropagation()}
           >
              <div className="p-8 md:p-10 border-b border-slate-50 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-10">
                <div>
                  <h3 className="text-xl font-black text-slate-900 tracking-tight uppercase">Scholar Node</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.3em] mt-2">Identity Snapshot</p>
                </div>
                <button 
                  onClick={() => setPreviewStudent(null)} 
                  className="w-12 h-12 flex items-center justify-center text-slate-300 hover:text-slate-900 bg-slate-50 rounded-2xl transition-all"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-10 md:p-12 space-y-10 custom-scrollbar">
                <div className="flex flex-col items-center text-center space-y-6 md:space-y-8">
                   <div className={`w-28 h-28 md:w-32 md:h-32 rounded-[2.5rem] md:rounded-[3rem] flex items-center justify-center font-black text-4xl shadow-inner ${previewStudent.isLocked ? 'bg-amber-50 text-amber-500 border border-amber-200' : 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/20'}`}>
                     {previewStudent.isLocked ? <Lock size={40} /> : previewStudent.name[0]}
                   </div>
                   <div>
                     <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight uppercase leading-none">{previewStudent.name}</h2>
                     <p className="text-[9px] md:text-[10px] text-slate-400 font-bold uppercase tracking-[0.4em] mt-4 bg-slate-50 px-6 py-2 rounded-full inline-block border border-slate-100">{previewStudent.regNo}</p>
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-3 md:gap-4">
                   <SummaryBadge icon={Briefcase} label={previewStudent.status} color="indigo" />
                   <SummaryBadge icon={ShieldAlert} label={previewStudent.isLocked ? 'LOCKED' : 'OPEN'} color={previewStudent.isLocked ? 'amber' : 'emerald'} />
                </div>

                <div className="space-y-8 pt-10 border-t border-slate-50">
                  <MetricRow icon={User} label="Father's Name" value={previewStudent.fatherName} />
                  <MetricRow icon={MapPin} label="Specialization" value={previewStudent.department} />
                  <MetricRow icon={Briefcase} label="Lead Supervisor" value={previewStudent.supervisorName} />
                  <MetricRow icon={GraduationCap} label="Degree Level" value={previewStudent.degree} />
                </div>
              </div>

              <div className="p-10 border-t border-slate-50 bg-slate-50/50">
                 <Link to={`/students/${previewStudent.id}`} className="w-full flex items-center justify-center space-x-4 py-6 bg-[#0a0c10] text-white rounded-3xl font-black text-xs uppercase tracking-[0.3em] hover:bg-indigo-600 transition-all shadow-2xl group active:scale-95">
                   <span>View Full Profile</span>
                   <ChevronRight size={18} className="group-hover:translate-x-2 transition-transform" />
                 </Link>
              </div>
           </div>
        </div>
      )}

      {/* Delete Confirmation Modal - Responsive */}
      {deletingId && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-[#0a0c10]/70 backdrop-blur-xl no-print">
           <div className="bg-white rounded-[3rem] md:rounded-[4rem] w-full max-w-md shadow-2xl overflow-hidden border border-white/20 animate-in zoom-in-95 duration-300">
              <div className="p-10 md:p-12 text-center space-y-6">
                 <div className="w-16 h-16 md:w-20 md:h-20 bg-rose-50 text-rose-600 rounded-[2rem] md:rounded-[2.5rem] flex items-center justify-center mx-auto shadow-inner"><Trash2 size={32} /></div>
                 <div className="space-y-2">
                    <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight uppercase">Purge Record?</h3>
                    <p className="text-slate-500 text-xs md:text-sm font-medium leading-relaxed">
                      Confirming will permanently remove this scholar node from the registry. This action is irreversible.
                    </p>
                 </div>
              </div>
              <div className="p-10 md:p-12 bg-slate-50 flex flex-col md:flex-row gap-4 md:gap-6">
                 <button onClick={() => setDeletingId(null)} className="flex-1 py-4 md:py-5 bg-white border border-slate-200 text-slate-700 rounded-2xl font-black text-[9px] md:text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all">Cancel</button>
                 <button 
                  onClick={() => { if(deletingId) deleteStudent(deletingId); setDeletingId(null); }} 
                  className="flex-1 py-4 md:py-5 bg-rose-600 text-white rounded-2xl font-black text-[9px] md:text-[10px] uppercase tracking-widest hover:bg-rose-700 transition-all shadow-xl shadow-rose-600/20"
                 >
                   Confirm Deletion
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

// Sub-components for better organization

const SummaryBadge = ({ icon: Icon, label, color }: any) => (
  <div className={`flex items-center space-x-2 md:space-x-3 px-4 py-2.5 rounded-xl border ${
    color === 'emerald' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
    color === 'amber' ? 'bg-amber-50 text-amber-600 border-amber-100' : 
    'bg-indigo-50 text-indigo-600 border-indigo-100'
  }`}>
    <Icon size={14} /><span className="text-[9px] font-black uppercase tracking-widest whitespace-nowrap">{label}</span>
  </div>
);

const MetricRow = ({ icon: Icon, label, value }: any) => (
  <div className="flex items-start space-x-4 group">
    <div className="p-2.5 md:p-3 bg-slate-50 text-slate-300 rounded-xl group-hover:text-indigo-600 group-hover:bg-indigo-50 transition-all shrink-0"><Icon size={18} /></div>
    <div className="flex-1 min-w-0">
      <p className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-xs md:text-sm font-bold text-slate-900 truncate tracking-tight">{value || '---'}</p>
    </div>
  </div>
);

const FilterSelect = ({ label, value, options, displayOptions, onChange, icon: Icon }: any) => (
  <div className="space-y-2.5">
    <label className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-2 block">{label}</label>
    <div className="relative group">
      <div className={`absolute left-5 top-1/2 -translate-y-1/2 z-10 transition-colors ${value !== '' ? 'text-indigo-600' : 'text-slate-300'}`}>
        <Icon size={16} />
      </div>
      <select 
        className={`w-full pl-14 pr-12 py-4 md:py-5 bg-slate-50 border rounded-2xl md:rounded-[1.5rem] text-[10px] md:text-[11px] font-black uppercase tracking-widest outline-none transition-all appearance-none cursor-pointer focus:ring-8 focus:ring-indigo-600/5 ${value !== '' ? 'border-indigo-600 text-indigo-600 bg-white' : 'border-slate-100 text-slate-500'}`}
        value={value} 
        onChange={e => onChange(e.target.value)}
      >
        <option value="">All Categories</option>
        {options.map((opt: string, idx: number) => (
          <option key={opt} value={opt}>{displayOptions ? displayOptions[idx] : opt}</option>
        ))}
      </select>
      <div className={`absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none transition-colors ${value !== '' ? 'text-indigo-600' : 'text-slate-300'}`}>
        <ChevronDown size={14} />
      </div>
    </div>
  </div>
);

export default StudentRecords;
