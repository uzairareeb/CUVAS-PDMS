
import React, { useState } from 'react';
import { useStore } from '../store';
import { 
  Building, 
  ShieldCheck, 
  CheckCircle, 
  Database,
  Upload,
  Image as ImageIcon,
  X,
  Save,
  Check
} from 'lucide-react';

const Settings: React.FC = () => {
  const { 
    settings, updateSettings, backupDatabase 
  } = useStore();
  
  const [activeTab, setActiveTab] = useState('institutional');
  const [localSettings, setLocalSettings] = useState(settings);
  const [showSavedToast, setShowSavedToast] = useState(false);

  const handleSave = () => {
    updateSettings(localSettings);
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 3000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("File size is too large. Please upload a logo smaller than 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setLocalSettings({
          ...localSettings,
          institution: {
            ...localSettings.institution,
            logo: result
          }
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    setLocalSettings({
      ...localSettings,
      institution: {
        ...localSettings.institution,
        logo: ""
      }
    });
  };

  const tabs = [
    { id: 'institutional', label: 'Institution', icon: Building },
    { id: 'security', label: 'Security', icon: ShieldCheck },
    { id: 'milestones', label: 'Milestones', icon: CheckCircle },
    { id: 'maintenance', label: 'Backups', icon: Database },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 md:space-y-10 animate-in fade-in duration-700 relative pb-20">
      {showSavedToast && (
        <div className="fixed top-24 right-4 md:right-10 z-[100] bg-emerald-600 text-white px-6 md:px-8 py-4 rounded-2xl shadow-2xl flex items-center space-x-3 animate-in slide-in-from-right-10">
          <Check size={20} className="stroke-[3]" />
          <span className="text-xs font-bold uppercase tracking-widest">Settings Saved</span>
        </div>
      )}

      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight">System Settings</h1>
        <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Manage University and System Configurations</p>
      </div>

      <div className="bg-white rounded-[2rem] md:rounded-[3.5rem] border border-slate-100 shadow-xl overflow-hidden flex flex-col lg:flex-row min-h-[auto] lg:min-h-[700px]">
        {/* Adaptive Tab Sidebar / Header */}
        <div className="w-full lg:w-80 bg-slate-50 border-b lg:border-b-0 lg:border-r border-slate-100 p-4 md:p-8 space-y-0 lg:space-y-2">
          <div className="grid grid-cols-2 gap-2 lg:block lg:space-y-2">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center justify-center lg:justify-start space-x-3 px-4 md:px-6 py-3 md:py-4 rounded-xl md:rounded-2xl transition-all font-bold text-[9px] md:text-[10px] uppercase tracking-widest ${
                  activeTab === tab.id ? 'bg-[#0f172a] text-white shadow-lg' : 'text-slate-400 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <tab.icon size={16} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
          
          <div className="hidden lg:block mt-12 pt-12 border-t border-slate-200">
             <button 
              onClick={handleSave}
              className="w-full bg-[#0f172a] text-white py-5 rounded-2xl font-bold text-[10px] uppercase tracking-[0.2em] shadow-xl hover:bg-indigo-600 active:scale-95 transition-all flex items-center justify-center space-x-2"
             >
               <Save size={16} />
               <span>Save Changes</span>
             </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="flex-1 p-6 md:p-14 bg-white overflow-y-auto max-h-[800px]">
          {activeTab === 'institutional' && (
            <div className="space-y-10 md:space-y-12">
              <SectionHeader title="University Details" desc="General information about your institution." />
              
              <div className="p-6 md:p-10 bg-slate-50 rounded-[2rem] md:rounded-[3rem] border border-slate-100 space-y-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 uppercase tracking-tight">University Logo</h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Upload logo for reports and dashboard</p>
                  </div>
                  <button 
                    onClick={handleSave}
                    className="w-full md:w-auto px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold text-[9px] uppercase tracking-[0.2em] shadow-lg hover:bg-indigo-700 transition-all flex items-center justify-center space-x-2 lg:hidden"
                  >
                    <Save size={14} />
                    <span>Save</span>
                  </button>
                </div>

                <div className="flex flex-col md:flex-row items-center gap-8 pt-4">
                  {localSettings.institution.logo ? (
                    <div className="relative group shrink-0">
                      <div className="h-32 w-32 md:h-40 md:w-40 rounded-[2rem] bg-white border border-slate-200 p-4 shadow-sm flex items-center justify-center overflow-hidden">
                        <img src={localSettings.institution.logo} className="max-h-full max-w-full object-contain" alt="Logo Preview" />
                      </div>
                      <button 
                        onClick={removeLogo}
                        className="absolute -top-2 -right-2 p-2 bg-rose-500 text-white rounded-full shadow-lg opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity hover:bg-rose-600"
                        title="Delete Logo"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="h-32 w-32 md:h-40 md:w-40 rounded-[2rem] border-2 border-dashed border-slate-200 bg-white flex flex-col items-center justify-center text-slate-300 space-y-3 shrink-0">
                       <ImageIcon size={32} className="opacity-30" />
                       <span className="text-[8px] font-bold uppercase tracking-tighter">No Logo</span>
                    </div>
                  )}
                  
                  <div className="flex-1 space-y-5 w-full text-center md:text-left">
                    <div className="space-y-2">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Logo Upload</p>
                      <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto md:mx-0">Upload your university logo. It will appear on all official documents and on the system dashboard.</p>
                    </div>
                    <label className="inline-flex items-center justify-center space-x-3 px-10 py-5 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold text-[10px] uppercase tracking-widest cursor-pointer hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all shadow-sm w-full md:w-auto">
                      <Upload size={18} />
                      <span>Choose File</span>
                      <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                    </label>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10">
                <Field label="University Name" value={localSettings.institution.name} 
                  onChange={v => setLocalSettings({...localSettings, institution: {...localSettings.institution, name: v}})} />
                <Field label="Department / Office Name" value={localSettings.institution.directorate} 
                  onChange={v => setLocalSettings({...localSettings, institution: {...localSettings.institution, directorate: v}})} />
                <Field label="Contact Email Address" value={localSettings.institution.email} 
                  onChange={v => setLocalSettings({...localSettings, institution: {...localSettings.institution, email: v}})} />
                <Field label="Academic Year" value={localSettings.institution.academicYear} 
                  onChange={v => setLocalSettings({...localSettings, institution: {...localSettings.institution, academicYear: v}})} />
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-10 md:space-y-12">
              <SectionHeader title="Security Settings" desc="Configure login sessions and record protections." />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10">
                <Field label="Auto-Logout Time (Minutes)" type="number" value={localSettings.security.sessionTimeout.toString()} 
                  onChange={v => setLocalSettings({...localSettings, security: {...localSettings.security, sessionTimeout: parseInt(v)}})} />
                <Field label="Maximum Login Attempts" type="number" value={localSettings.security.maxLoginAttempts.toString()} 
                  onChange={v => setLocalSettings({...localSettings, security: {...localSettings.security, maxLoginAttempts: parseInt(v)}})} />
                <ToggleField label="Lock Records After Submission" value={localSettings.security.enableRecordLocking} 
                  onChange={v => setLocalSettings({...localSettings, security: {...localSettings.security, enableRecordLocking: v}})} />
                <ToggleField label="Allow Record Deletion" value={localSettings.security.enableDeletion} 
                  onChange={v => setLocalSettings({...localSettings, security: {...localSettings.security, enableDeletion: v}})} />
              </div>
            </div>
          )}

          {activeTab === 'maintenance' && (
            <div className="space-y-10 md:space-y-12">
              <SectionHeader title="System Maintenance" desc="Backup your data and check system version." />
              <div className="bg-[#0f172a] p-8 md:p-12 rounded-[2.5rem] md:rounded-[3.5rem] text-white space-y-8 md:space-y-10 relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 blur-[60px] rounded-full" />
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">System Version</p>
                    <p className="text-2xl md:text-3xl font-bold text-indigo-400">{localSettings.maintenance.version}</p>
                  </div>
                  <div className="text-left md:text-right">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Last Backup Date</p>
                    <p className="text-sm font-bold text-slate-300">{localSettings.maintenance.lastBackup}</p>
                  </div>
                </div>
                <button 
                  onClick={backupDatabase}
                  className="w-full flex items-center justify-center space-x-4 py-6 md:py-8 bg-white/5 border-2 border-dashed border-indigo-500/30 text-indigo-400 rounded-3xl hover:bg-white/10 hover:border-indigo-400 transition-all font-bold text-[10px] uppercase tracking-[0.3em] active:scale-[0.98]"
                >
                  <Database size={24} />
                  <span>Download Data Backup File</span>
                </button>
              </div>
            </div>
          )}

          {/* Mobile Save Button (Sticky Bottom) */}
          <div className="lg:hidden mt-10 pt-6 border-t border-slate-100">
             <button 
              onClick={handleSave}
              className="w-full bg-[#0f172a] text-white py-5 rounded-2xl font-bold text-[10px] uppercase tracking-[0.2em] shadow-xl hover:bg-indigo-600 active:scale-95 transition-all flex items-center justify-center space-x-2"
             >
               <Save size={16} />
               <span>Save Changes</span>
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const SectionHeader = ({ title, desc }: any) => (
  <div className="border-b border-slate-50 pb-6 md:pb-8">
    <h3 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight uppercase">{title}</h3>
    <p className="text-slate-400 text-xs font-medium mt-1">{desc}</p>
  </div>
);

const Field = ({ label, value, onChange, type = "text", readOnly = false }: any) => (
  <div className="space-y-3">
    <label className="text-[9px] font-bold uppercase tracking-widest text-slate-400 ml-1">{label}</label>
    <input 
      type={type}
      readOnly={readOnly}
      className={`w-full px-6 py-4 md:px-7 md:py-5 bg-slate-50 border border-slate-100 rounded-[1.5rem] text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 transition-all ${readOnly ? 'opacity-50 cursor-not-allowed' : ''}`}
      value={value || ''}
      onChange={e => onChange?.(e.target.value)}
    />
  </div>
);

const ToggleField = ({ label, value, onChange }: any) => (
  <div className="flex items-center justify-between p-5 md:p-7 bg-slate-50 rounded-[1.5rem] border border-slate-100">
    <span className="text-[9px] font-bold uppercase tracking-widest text-slate-600 pr-4">{label}</span>
    <button 
      onClick={() => onChange(!value)}
      className={`w-14 h-8 rounded-full transition-all relative shrink-0 ${value ? 'bg-indigo-600' : 'bg-slate-300'}`}
    >
      <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all ${value ? 'left-7' : 'left-1'}`} />
    </button>
  </div>
);

export default Settings;
