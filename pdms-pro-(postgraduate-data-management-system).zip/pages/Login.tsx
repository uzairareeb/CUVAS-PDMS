
import React, { useState } from 'react';
import { useStore } from '../store';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, User, Info, ArrowRight, AlertCircle, Maximize, Minimize } from 'lucide-react';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login, notify, settings } = useStore();
  const navigate = useNavigate();
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === 'admin123') {
      login(username);
      navigate('/');
    } else {
      notify('Authentication failed: Invalid credentials provided.', 'error');
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-white overflow-hidden relative">
      {/* Fullscreen Command Toggle */}
      <button 
        onClick={toggleFullscreen}
        className="absolute top-8 right-8 z-50 p-4 bg-slate-900/5 hover:bg-slate-900/10 text-slate-400 hover:text-indigo-600 rounded-2xl transition-all border border-transparent hover:border-slate-100 shadow-sm backdrop-blur-sm group"
        title={isFullscreen ? "Exit Fullscreen Protocol" : "Engage Full-Page View"}
      >
        {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
      </button>

      {/* System Information Side */}
      <div className="hidden lg:flex w-7/12 bg-[#0f172a] relative items-center justify-center p-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,_rgba(79,102,241,0.1),_transparent)]" />
        <div className="relative z-10 max-w-xl space-y-10">
          <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-600/30">
              <ShieldCheck size={48} className="text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white tracking-tight uppercase leading-none">System Identity</h1>
              <p className="text-indigo-400 font-bold uppercase tracking-[0.2em] text-[10px] mt-2">{settings.institution.directorate}</p>
            </div>
          </div>
          
          <div className="space-y-6">
            <h2 className="text-5xl font-black text-white leading-tight tracking-tighter">
              Postgraduate Data <br /> <span className="text-indigo-500">Management</span> System.
            </h2>
            <p className="text-slate-400 text-lg font-medium leading-relaxed">
              Internal Academic Record Management and Monitoring System for advanced postgraduate studies and institutional research tracking.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 pt-10 border-t border-white/10">
            <Feature icon={ShieldCheck} title="Record Security" desc="Encrypted data persistence" />
            <Feature icon={Info} title="Milestone Sync" desc="Automated GS Form tracking" />
          </div>

          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.5em] pt-12">
            {settings.institution.systemName} PRO
          </p>
        </div>
      </div>

      {/* Authorized Access Side */}
      <div className="w-full lg:w-5/12 flex flex-col justify-center px-10 md:px-24 bg-white relative">
        <div className="max-w-sm w-full mx-auto space-y-12">
          <div className="space-y-3">
            <h3 className="text-3xl font-black text-slate-900 tracking-tight">Authorized Access Only</h3>
            <p className="text-slate-400 font-semibold text-sm">Please enter your administrative credentials.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Username</label>
              <div className="relative group">
                <User className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={20} />
                <input 
                  required
                  type="text" 
                  className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                  placeholder="admin"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Password</label>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" size={20} />
                <input 
                  required
                  type="password" 
                  className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full py-5 bg-[#0f172a] text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl shadow-slate-900/10 active:scale-[0.98] flex items-center justify-center space-x-3 group"
            >
              <span>Sign In</span>
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="text-center">
            <p className="text-[9px] text-slate-300 font-bold uppercase tracking-[0.2em]">
              Security logging active. All access attempts recorded.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const Feature = ({ icon: Icon, title, desc }: any) => (
  <div className="flex items-start space-x-3">
    <div className="p-2 bg-white/5 text-indigo-400 rounded-xl">
      <Icon size={18} />
    </div>
    <div>
      <h4 className="text-white text-[10px] font-black uppercase tracking-widest">{title}</h4>
      <p className="text-slate-500 text-[10px] font-medium mt-0.5">{desc}</p>
    </div>
  </div>
);

export default Login;
