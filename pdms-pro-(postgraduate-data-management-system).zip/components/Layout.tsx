
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { 
  LayoutDashboard, 
  UserPlus, 
  Users, 
  CloudUpload, 
  FileSpreadsheet, 
  History, 
  BarChart3, 
  Settings as SettingsIcon, 
  LogOut,
  ChevronRight,
  ShieldCheck,
  Users2,
  Download,
  Maximize,
  Minimize,
  ClipboardList,
  Menu,
  X,
  BookOpenCheck
} from 'lucide-react';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { pathname } = useLocation();
  const { currentUser, currentRole, logout, settings } = useStore();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Close sidebar on navigation (mobile)
  useEffect(() => {
    setIsSidebarOpen(false);
  }, [pathname]);

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { name: 'Student Registration', icon: UserPlus, path: '/registration' },
    { name: 'Student Records', icon: Users, path: '/records' },
    { name: 'Synopsis Tracking', icon: ClipboardList, path: '/synopsis-submission' },
    { name: 'Thesis Tracking', icon: BookOpenCheck, path: '/thesis-tracking' },
    { name: 'Bulk Data Upload', icon: CloudUpload, path: '/upload' },
    { name: 'Data Export (CSV)', icon: Download, path: '/export' },
    { name: 'System Reports', icon: BarChart3, path: '/reports' },
    { name: 'Audit Trail', icon: History, path: '/audit' },
    { name: 'User Management', icon: Users2, path: '/users', adminOnly: true },
    { name: 'System Settings', icon: SettingsIcon, path: '/settings', adminOnly: true },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  if (!currentUser) return <>{children}</>;

  return (
    <div className="flex min-h-screen bg-[#f8fafc]">
      {/* Sidebar Overlay (Mobile) */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[90] lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 w-72 md:w-80 bg-[#0f172a] text-white flex flex-col z-[100] transition-transform duration-300 ease-in-out no-print shadow-2xl
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6 md:p-8 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center space-x-3 md:space-x-4">
            {settings.institution.logo ? (
              <img src={settings.institution.logo} className="w-10 h-10 md:w-12 md:h-12 object-contain" alt="Sidebar Logo" />
            ) : (
              <div className="w-10 h-10 md:w-12 md:h-12 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                <ShieldCheck size={24} className="text-white" />
              </div>
            )}
            <div>
              <h1 className="text-base md:text-lg font-black tracking-tight leading-none uppercase">PDMS-PRO</h1>
              <p className="text-[8px] md:text-[9px] text-slate-500 font-bold uppercase tracking-[0.2em] mt-1">Institutional Portal</p>
            </div>
          </div>
          <button 
            className="lg:hidden text-slate-400 hover:text-white transition-colors"
            onClick={() => setIsSidebarOpen(false)}
          >
            <X size={20} />
          </button>
        </div>
        
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.path;
            if (item.adminOnly && currentRole?.roleName !== 'System Administrator') return null;

            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center justify-between px-5 md:px-6 py-3.5 md:py-4 rounded-xl md:rounded-2xl transition-all group ${
                  isActive 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 translate-x-1' 
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-3 md:space-x-4">
                  <Icon size={18} className={isActive ? 'text-white' : 'group-hover:text-indigo-400'} />
                  <span className="text-[10px] md:text-[11px] font-bold uppercase tracking-widest">{item.name}</span>
                </div>
                {isActive && <ChevronRight size={14} className="opacity-50" />}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 md:p-6 border-t border-white/5 bg-[#0a0c1a]">
          <div className="flex items-center space-x-3 md:space-x-4 mb-4">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center font-black text-indigo-500">
              {currentUser[0]}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white truncate uppercase tracking-wider">{currentUser}</p>
              <p className="text-[9px] text-indigo-400 font-bold uppercase mt-0.5">{currentRole?.roleName}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center space-x-2 py-3 bg-red-600/10 text-red-500 hover:bg-red-600 hover:text-white rounded-xl transition-all font-bold text-[10px] uppercase tracking-widest"
          >
            <LogOut size={14} />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-h-screen lg:ml-72 xl:ml-80 transition-all duration-300 w-full">
        <header className="h-16 md:h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-4 md:px-10 sticky top-0 z-20 no-print">
          <div className="flex items-center space-x-4">
            <button 
              className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              onClick={() => setIsSidebarOpen(true)}
            >
              <Menu size={24} />
            </button>
            <div className="hidden sm:block">
              <h2 className="text-xs md:text-sm font-black text-slate-900 tracking-tight uppercase">
                {menuItems.find(i => i.path === pathname)?.name || 'Scholar Identity'}
              </h2>
              <p className="text-[8px] md:text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 md:space-x-4">
             <div className="text-right hidden sm:block">
                <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">{settings.institution.academicYear}</p>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">Academic Year</p>
             </div>
             <div className="h-8 w-px bg-slate-200 mx-1 md:mx-2 hidden sm:block" />
             
             <button 
              onClick={toggleFullscreen}
              className="p-2 md:p-3 bg-slate-50 text-slate-400 hover:text-indigo-600 rounded-lg md:rounded-xl transition-all border border-transparent hover:border-slate-100 shadow-sm"
              title={isFullscreen ? "Exit Fullscreen" : "Engage Full-Page View"}
             >
                {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
             </button>

             <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shadow-sm">
                <ShieldCheck size={20} className="text-indigo-600" />
             </div>
          </div>
        </header>

        <div className="p-4 md:p-8 lg:p-10 max-w-[1600px] mx-auto w-full">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
